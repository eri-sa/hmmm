<?php 
session_start();
require_once 'config.php';


	if (isset($_SESSION['email'])) {
		$email = $_SESSION['email'];

		$sql = "SELECT * FROM users WHERE email ='$email'";
		$select_user_profile = mysqli_query($connection,$sql);
		while($row = mysqli_fetch_assoc($select_user_profile)){
	    $user_id= $row['id'];
	    $firstname = $row['firstname'];
	    $lastname = $row['lastname'];
	    $email = $row['email'];
	    $phonenumber = $row['phonenumber'];
	    $password = $row['password'];
	   }
	}

	if(isset($_SESSION['email'])){
	if (isset($_POST['save'])) {

		$email = $_SESSION['email'];
		$cu_pass = sha1($_POST['pass']);
	    $password = sha1($_POST['password']);
    	$confirm_password = sha1($_POST['password1']);

		$sel_query = "SELECT * FROM users WHERE email = '{$email}' ";
		$res_sel = mysqli_query($connection, $sel_query);

		while($row = mysqli_fetch_assoc($res_sel)){
			$db_pass = $row['password'];
		}

		if($cu_pass === $db_pass){


		if ($password === $confirm_password) {
			$query= "UPDATE users SET password='$password' WHERE email='$email' ";
			$result = mysqli_query($connection,$query);
			if($result){
				
				
				echo '<div class="alert alert-success alert-dismissible fade in">
    		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    		 	<strong>Success!</strong>The password has been changed.
 		 	</div>';

		}
		
		    }else {
			echo '<div class="alert alert-danger alert-dismissible fade in">
    		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    		 	<strong>Try Again!</strong> Please enter the correct password.
 		 	</div>';
		}

          

          }else{
          	echo '<div class="alert alert-danger alert-dismissible fade in">
    		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    		 	<strong>Try Again!</strong>Please enter the correct password.
 		 	</div>';

          }
		

	}
}

	if(isset($_POST['update'])){
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $email = $_POST['email'];    
    $phonenumber = $_POST['phonenumber'];
    $query = "UPDATE users SET firstname ='$firstname',lastname='$lastname',email='$email',phonenumber='$phonenumber' WHERE email='$email' ";
    $edit_user_query = mysqli_query($connection, $query);

    if ($edit_user_query) {
    	
    	echo '<div class="alert alert-success alert-dismissible fade in">
    		<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    		 	<strong>Success!</strong> Your information has been changed.
 		 	</div>';

 		 }

}

 ?>