<?php  
session_start();
require_once 'config.php';

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = sha1($_POST['password']);    
        
    $sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password' ";
    $result = mysqli_query($connection, $sql);
    $count = mysqli_num_rows($result);

    if($count ==1){
    while($row = mysqli_fetch_assoc($result)){
          $db_user_email = $row['email'];
          $db_user_password = $row['password'];
          $firstname = $row['firstname'];
      }
      if($password === $db_user_password){
        
           $_SESSION['firstname']=$firstname; 
           $_SESSION['email'] = $email;
           $_SESSION['password'] = $password;
           
         header("Location:main.php");
        }   
    else {
            
            echo "Failed!";
        }
    }
}

?>


<html>
<head>
	<title> Login Page</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"> 
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" type="text/css" href="style/loginstyle.css">
	
</head>
<body>

	<div class="img"></div>
	<form action="" method="post">
		
			<div class="container">
				
					<h1>Login</h1>
				
					<hr class="mb-3">
					<label for="email"><b>Email</b></label>
					<input class="form-control" id="email" type="email" name="email" placeholder="Enter yor email"  required>

					<label for="password"><b>Password</b></label>
			 		<input class="form-control" id="password" type="password" name="password" placeholder="Enter your password" required><br>
					<p><a href="register.php">Forgot Email or Password?</a></p>
					<hr class="mb-3">
					<input class="btn btn-dark" type="submit" id="login" name="login" value="Sign in"><br><br>
				    <p><a href="register.php">Create an account</a></p>
			</div>	
		
	</form>
	

</body>
</html>