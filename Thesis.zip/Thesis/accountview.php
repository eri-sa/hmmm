
<!DOCTYPE html>
<html>
<head>
	<title>Your Profile</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style/passStyle.css">

 <style>



 </style>

</head>
<body>


	<nav class="navbar navbar-inverse" role="navigation">
		<div class="navbar-header">
			<a class="navbar-brand" href="main.php"><span class="glyphicon glyphicon-home"></span></a>
		</div>
		<ul class="nav navbar-nav navbar-right">

			<li><a href="logout.php"><span class="glyphicon glyphicon-log-out"></span>Logout</a></li>
			
		</ul>
		
	</nav>
	<?php 
include 'acc_conf.php';
 ?>

	
<div class="container">
	<div class="row justify-content-center">
		 
		<h1>Edit Your Profile</h1>
		<table class="table">
			<thead>
				<tr>
					<th>Name</th>
					<th>Lastname</th>
					<th>Email</th>
					<th>Phone Number</th>
					
				</tr>
			</thead>
			<tr>
				<td><?php echo $firstname ?></td>
				<td><?php echo $lastname ?></td>
				<td><?php echo $email ?></td>
				<td><?php echo $phonenumber ?></td>
			</tr>
			
		</table>
		
	</div>


<div class="row justify-content-center">
	<form class="" action="" method="post">
		<div class="form-group">
			
			<label>First Name</label><br>
			<input type="text" name="firstname" class="form-control" value="<?php echo $firstname; ?> " ><br>
			<label>Lastname</label><br>
			<input type="text" name="lastname" class="form-control" value="<?php echo $lastname; ?> "><br>
			<label>Email</label><br>
			<input type="email" name="email" class="form-control" value="<?php echo $email; ?> "><br>
			<label>Phone Number</label><br>
			<input type="phone" name="phonenumber" class="form-control" value="<?php echo $phonenumber; ?> "><br>
			<button class="btn btn-primary" type="submit" name="update">Update</button>
			<a href="main.php" type="button" class="btn btn-danger">Cancel</a>
			<script>
				
			</script>	
  </div>
		</div>
	</form>
</div>
</div>

<button class="open-button" onclick="openForm()">Change Password</button>

<div class="form-popup" id="myForm">
  <form action="" class="form-container" method="post">

    <label for="password"><b>Current Password</b></label>
    <input type="password" placeholder="Current Password" name="pass" required>

    <label for="password"><b>New Password</b></label>
    <input type="password" placeholder="New Password" name="password" required>

    <label for="password"><b>Confirm Password</b></label>
    <input type="password" placeholder="Re-enter Password" name="password1" required>

    <button type="submit" class="btn" name="save">Save</button>
    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
  </form>
</div>

<script>
function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}
</script>

</body>
</html>