<?php   
// $DSN = 'mysql:host=localhost;dbname=users';
// $ConnectingDB = new PDO($DSN,'root',''); 

?>

<?php 
$connection = mysqli_connect('localhost', 'root', '','users');
if(!$connection){
	die("Failed" . mysqli_error($connection)); 
} 
?>
