<?php ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="style/indexstyle.css">



</head>
<body background="images/back.jpg">

	<nav class="navbar navbar-inverse">
		<div class="container-fluid">
			<div class="navbar-inner">
				<div  class="collapse navbar-collapse" id="collapse">
					<ul class="nav navbar-nav navbar-right">
						<li ><a class="glyphicon glyphicon-user" href="register.php">Register</a></li>
						<li ><a class="glyphicon glyphicon-log-in" href="login.php">Login</a></li>
					</ul>
				</div>
			</div>		
		</div>		
	</nav>

	
	

	<div class="ab">
	<h2>4 Years, 40 Subjects, 400 Experiments, 4000 Assignments, 40000 hours A normal human being CANNOT do it. Those super heroes are calles 'ENGINEER STUDENTS'.</h2>
				
	</div>

	

</body>
</html>